# Transposing Data from an Aircraft

As the Transpose window has two modes, long and wide, this example consists of two parts:
- The [esp-studio-examples/Advanced/transpose_wide/](https://github.com/sassoftware/esp-studio-examples/tree/main/Advanced/transpose_wide) directory contains the resources for wide mode
- The [esp-studio-examples/Advanced/transpose_long/](https://github.com/sassoftware/esp-studio-examples/tree/main/Advanced/transpose_long) directory contains the resources for long mode

The README in [esp-studio-examples/Advanced/transpose_wide/](https://github.com/sassoftware/esp-studio-examples/tree/main/Advanced/transpose_wide) provides instructions for both wide mode and long mode.
