# compute

Use a Compute window to match people from the city of Apex.

You can use Compute windows to project input fields from one event to a new event and to augment this event with fields that result from a calculation.

For more information about how to explore and test this project, see [Using the Examples](https://github.com/sassoftware/esp-studio-examples#using-the-examples).
